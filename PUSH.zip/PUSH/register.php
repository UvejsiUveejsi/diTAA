<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>

<div class="w-50 mx-auto" style="padding-top: 100px;">
        <h1 class="mb-3">Please sign up</h1>
        <form>


        <div data-mdb-input-init class="form-outline mb-4">
    <input type="name" id="form2Example2" class="form-control" />
    <label class="form-label" for="form2Example2">Name</label> 

    <div data-mdb-input-init class="form-outline mb-4">
    <input type="surname" id="form2Example2" class="form-control" />
    <label class="form-label" for="form2Example2">Surname</label>

    <div data-mdb-input-init class="form-outline mb-4">
    <input type="username" id="form2Example2" class="form-control" />
    <label class="form-label" for="form2Example2">Username</label>


  <div data-mdb-input-init class="form-outline mb-4">
    <input type="email" id="form2Example1" class="form-control" />
    <label class="form-label" for="form2Example1">Email address</label>
  </div>

  <!-- Password input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="password" id="form2Example2" class="form-control" />
    <label class="form-label" for="form2Example2">Password</label>
  </div>
  <!-- Submit button -->
  <button  type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-block mb-4">Sign in</button>
  <!-- Register buttons -->
  <div class="text-center">
    <p>Alr have acc?? <a href="#!">Login</a></p>
    <p>or sign up with:</p>
  </div>
</form>
    </div>








<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</script>
</body>
</html>